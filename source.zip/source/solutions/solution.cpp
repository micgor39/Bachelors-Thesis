#include "solution.h"

solution::~solution() {}